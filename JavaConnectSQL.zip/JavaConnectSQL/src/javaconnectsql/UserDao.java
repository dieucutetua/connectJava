/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaconnectsql;
import static javaconnectsql.Diu_connection.JDBCConnection;
import model.user;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author DELL
 */
public class UserDao {
    public List<user> getAllUsers() {
        List<user> users = new ArrayList<user>();

        Connection connection = Diu_connection.JDBCConnection();
        String sql = "select * from users";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                user user = new user();
                user.setId(rs.getInt("ID"));
                user.setName(rs.getString("Ten"));
                user.setPhone(rs.getString("Sodt"));
                user.setUsername(rs.getString("Username"));
                user.setPassword(rs.getString("Pass"));
                user.setAbout(rs.getString("About"));
                user.setRole(rs.getString("Roles"));
                user.setFavourite(rs.getString("Favourite"));
                users.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return users;
    }

    public void addUser(user user) {
        Connection connection = Diu_connection.JDBCConnection();
        String sql = "insert into users(name , phone , username , password , about , favourites , role)";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getPhone());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setString(5, user.getAbout());
            preparedStatement.setString(6, user.getFavourite());
            preparedStatement.setString(7, user.getRole());
            int rs = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void updateUser(user user){
        Connection connection = Diu_connection.JDBCConnection();
        String sql = "Update users set name = ? , phone = ? , username = ? , password = ? , "
                + " about = ? , favourites = ? , role = ? where id = ? ";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getPhone());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setString(5, user.getAbout());
            preparedStatement.setString(6, user.getFavourite());
            preparedStatement.setString(7, user.getRole());
            preparedStatement.setInt(7, user.getId());
            int rs = preparedStatement.executeUpdate();
            System.out.println(rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void deleteUser(int id){
       Connection connection = Diu_connection.JDBCConnection();
       String sql = "delete from users where id = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);
            int rs = preparedStatement.executeUpdate();
            System.out.println(rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
