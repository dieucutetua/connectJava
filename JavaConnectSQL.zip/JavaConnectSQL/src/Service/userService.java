/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;
import javaconnectsql.UserDao;
import model.user;
import java.util.List;
/**
 *
 * @author DELL
 */
public class userService {
    private UserDao userDao;

    public userService() {
        userDao = new UserDao();
    }
    
    public  List<user> getAllUers(){
        return userDao.getAllUsers();
    }
    //public void addUser(user user){
    //    userDao.addUser(user);
    //}
}
